package com.scorpion.pojo;

/**
 * Created by Scorpion on 2017/10/2.
 * 统计重中之重企业新闻中行业新闻量统计
 */
public class IndustryCount {
    private String industry;
    private int count;

    public String getIndustry() {
        return industry;
    }

    public void setIndustry(String industry) {
        this.industry = industry;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
