package com.scorpion.pojo;

/**
 * 新闻来源实体类（企业预警需要的）
 * Created by Scorpion on 2017/5/4.
 */
public class SourceOfNews {
    private String source;
    private int num;

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }
}
